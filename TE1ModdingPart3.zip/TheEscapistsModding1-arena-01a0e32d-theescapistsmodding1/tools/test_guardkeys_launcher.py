#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""End-to-end test for the Guard Key Names mod inside TE1_Mod_Launcher.bat.

Builds a fake game folder with REAL game executables, drives the launcher
engine through install -> re-apply -> Steam-restore -> heal -> uninstall
and checks the executables byte for byte at every step.

Needs sample executables (the full two-level builds with the npc_rename
frame, ~8 MB each). Point TE1_SAMPLE_EXE / TE1_SAMPLE_EXE2 at them, or drop
them into one of the fallback locations below. Without samples the test
skips cleanly (exit code 0, prints SKIP) so it can stay in the repo.
"""
from __future__ import annotations
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BAT = ROOT / "TE1_Mod_Launcher.bat"
BEGIN = "#<ENGINE>"
END = "#</ENGINE>"

ok = True


def check(label, cond, extra=""):
    global ok
    print("  %-4s %s%s" % ("OK" if cond else "FAIL", label,
                           ("  -- " + extra) if extra and not cond else ""))
    if not cond:
        ok = False


def unpack_engine(dst):
    with open(str(BAT), "r", encoding="ascii", newline="") as fh:
        lines = fh.read().split("\r\n")
    i = lines.index(BEGIN)
    j = lines.index(END)
    dst.write_text("\n".join(lines[i + 1:j]) + "\n", encoding="ascii")


def run(engine, game, *args):
    return subprocess.run([sys.executable, str(engine), "--game", str(game)]
                          + list(args),
                          capture_output=True, text=True, encoding="utf-8")


def find_samples():
    def fix(p):
        return Path(os.environ[p]) if os.environ.get(p) else None
    cands = [fix("TE1_SAMPLE_EXE"), fix("TE1_SAMPLE_EXE2")]
    cands += [Path("/tmp/te1_extract/part1/exe/game/TheEscapists_eur.exe.txt"),
              Path("/tmp/te1_extract/part1/exe/game/TheEscapists_rus.exe.txt"),
              Path("/tmp/te1_extract/part2/exe/game/TheEscapists_pol.exe.txt")]
    out = []
    for c in cands:
        if c and c.exists() and c not in out:
            out.append(c)
    return out


def make_game(work, samples, with_real=True):
    game = work / "game"
    if game.exists():
        shutil.rmtree(game)
    (game / "Data").mkdir(parents=True)
    # a real Data folder keeps the val.dat rebuild happy
    for f in sorted((ROOT / "data_samples").glob("*.dat")):
        (game / "Data" / f.name).write_bytes(f.read_bytes())
    # the small front end: never carries the mod, must be skipped gracefully
    frontend = Path("/tmp/te1_extract/part1/exe/game/TheEscapists.exe.txt")
    if frontend.exists():
        (game / "TheEscapists.exe").write_bytes(frontend.read_bytes())
    else:
        (game / "TheEscapists.exe").write_bytes(b"not a fusion exe\n")
    names = ["theescapists_eur.exe", "theescapists_rus.exe",
             "theescapists_pol.exe"]
    if with_real:
        for src, name in zip(samples, names):
            (game / name).write_bytes(src.read_bytes())
    return game


def main():
    samples = find_samples()
    if not samples:
        print("SKIP: no sample executables "
              "(set TE1_SAMPLE_EXE=/path/to/TheEscapists_eur.exe)")
        return 0
    print("samples:")
    for s in samples:
        print("  %s (%d bytes)" % (s, s.stat().st_size))

    work = Path(tempfile.mkdtemp(prefix="te1_gk_test_"))
    try:
        engine = work / "te1_engine.py"
        unpack_engine(engine)
        body = engine.read_text(encoding="ascii")
        check("engine is pure ASCII",
              all(ord(c) < 127 for c in body))
        check("guard_keys section present",
              '"guard_keys"' in body and "npc_rename" in body
              and "Guard Key Names" in body)

        print("1. install via --apply")
        game = make_game(work, samples)
        real_names = sorted(f.name for f in game.glob("theescapists_*.exe"))
        before = {f: f.read_bytes() for f in game.glob("*.exe")}
        state = game / "mods" / "mods.json"
        state.parent.mkdir(parents=True, exist_ok=True)
        state.write_text(json.dumps({"guard_keys": True}), encoding="utf-8")
        p = run(engine, game, "--apply")
        print("     " + "\n     ".join(p.stdout.strip().splitlines()))
        check("apply exited cleanly", p.returncode == 0, p.stderr[-400:])
        check("every real game exe got patched",
              all("patched" in p.stdout and n in p.stdout for n in real_names))
        check("front-end skipped with a reason",
              "TheEscapists.exe skipped" in p.stdout)
        for n in real_names:
            exe = game / n
            check("%s bytes changed" % n, exe.read_bytes() != before[exe])
            bak = game / "mods" / "original" / "exe" / n
            check("%s backup == pristine exe" % n,
                  bak.exists() and bak.read_bytes() == before[exe])
        check("front-end untouched",
              (game / "TheEscapists.exe").read_bytes()
              == before[game / "TheEscapists.exe"])

        print("2. cross-check with the standalone patcher")
        chk = ROOT / "mods" / "guard_keys" / "te1_guardkeys.py"
        for n in real_names[:1]:
            q = subprocess.run([sys.executable, str(chk), "check",
                                str(game / n)],
                               capture_output=True, text=True,
                               encoding="utf-8")
            check("standalone check sees the mod (rc=0)", q.returncode == 0,
                  q.stdout[-300:] + q.stderr[-300:])
            check("standalone check reports 'already installed'",
                  "УЖЕ УСТАНОВЛЕН" in q.stdout.encode("utf-8").decode("utf-8")
                  if q.returncode == 0 else False)

        print("3. second apply is idempotent")
        p2 = run(engine, game, "--apply")
        check("re-apply clean", p2.returncode == 0)
        check("idempotent: no double patch", "was already patched" in p2.stdout)

        print("4. 'Steam verify' wipes the exe -> launch heals it")
        victim = game / real_names[0]
        victim.write_bytes(before[victim])
        p3 = run(engine, game, "--apply")
        check("heal clean", p3.returncode == 0)
        check("exe re-patched after Steam restore",
              victim.read_bytes() != before[victim])
        check("backup still the pristine one",
              (game / "mods" / "original" / "exe" / real_names[0]).read_bytes()
              == before[victim])

        print("5. --status shows per-exe state")
        p4 = run(engine, game, "--status")
        modline = [l for l in p4.stdout.splitlines()
                   if l.startswith("Guard Key Names")]
        check("status lists the mod",
              bool(modline) and modline[0].rstrip().endswith("True"),
              p4.stdout)
        check("status shows exe state",
              any("theescapists_eur.exe" in l and "patched" in l
                  for l in p4.stdout.splitlines()), p4.stdout[-400:])

        import importlib.util
        spec = importlib.util.spec_from_file_location("te1_engine_gk", str(engine))
        eng = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(eng)

        print("6. a write that gets mangled on disk is rolled back")
        game3 = make_game(work / "rollback", samples)
        victim3 = game3 / real_names[0]
        pristine3 = victim3.read_bytes()
        real_replace = eng.os.replace

        def bad_replace(src, dst):        # an antivirus / quota eating the write
            real_replace(src, dst)
            with open(str(dst), "r+b") as fh:
                fh.seek(len(pristine3) - 4096)
                fh.write(b"X" * 64)

        eng.os.replace = bad_replace
        try:
            status, detail = eng.gk_patch_exe(
                victim3, game3 / "mods" / "original" / "exe")
        finally:
            eng.os.replace = real_replace
        check("mangled write is detected", status == "failed",
              "%s / %s" % (status, detail))
        check("reason is reported", "put back" in detail, detail)
        check("pristine exe is back after the rollback",
              victim3.read_bytes() == pristine3)
        check("the backup is still the pristine one",
              (game3 / "mods" / "original" / "exe" / real_names[0]).read_bytes()
              == pristine3)

        print("7. a damaged exe is healed from the backup")
        game4 = make_game(work / "damaged", samples)
        st4 = game4 / "mods" / "mods.json"
        st4.parent.mkdir(parents=True, exist_ok=True)
        st4.write_text(json.dumps({"guard_keys": True}), encoding="utf-8")
        run(engine, game4, "--apply")
        victim4 = game4 / real_names[0]
        pristine4 = (game4 / "mods" / "original" / "exe" / real_names[0]).read_bytes()
        # half the file gone: exactly what a killed write or an antivirus
        # "repair" leaves behind
        victim4.write_bytes(victim4.read_bytes()[:len(pristine4) // 2])
        check("half an exe counts as damaged",
              eng.gk_exe_state(victim4) == "unreadable",
              eng.gk_exe_state(victim4))
        p7 = run(engine, game4, "--apply")
        check("heal ran cleanly", p7.returncode == 0, p7.stderr[-300:])
        check("the damage is reported",
              "was damaged - the pristine backup was put back" in p7.stdout,
              p7.stdout[-400:])
        check("the exe is patched again after the heal",
              eng.gk_exe_state(victim4) == "patched")
        check("its size is pristine + 112 bytes again",
              victim4.stat().st_size == len(pristine4) + 112)

        print("8. --status prints size and sha1 of every exe")
        p8 = run(engine, game4, "--status")
        check("status lists the exe with its size",
              "theescapists_eur.exe" in p8.stdout and "bytes" in p8.stdout
              and "sha1" in p8.stdout, p8.stdout[-500:])
        check("status shows the pristine backup and the delta",
              "backup (pristine)" in p8.stdout and "[+112]" in p8.stdout,
              p8.stdout[-500:])

        print("9. refuses to patch while the game is running")
        launcher3 = eng.Launcher(game3)
        real_pids = eng.running_pids
        eng.IS_WINDOWS = True
        eng.running_pids = lambda names: {4242}
        try:
            ok3, log3 = launcher3.gk_apply()
        finally:
            eng.running_pids = real_pids
            eng.IS_WINDOWS = False
        check("no patching under a running game", not ok3)
        check("the player is told why",
              any("still running" in line for line in log3), str(log3))

        print("10. game folder with only the front end -> honest failure")
        game2 = make_game(work / "bare", [], with_real=False)
        st2 = game2 / "mods" / "mods.json"
        st2.parent.mkdir(parents=True, exist_ok=True)
        st2.write_text(json.dumps({"guard_keys": True}), encoding="utf-8")
        p5 = run(engine, game2, "--apply")
        check("no real game -> apply fails loudly", p5.returncode != 0)
        check("reason is printed",
              "not a single executable" in p5.stdout)

        print("11. uninstall puts the pristine exes back")
        script = ("import sys; sys.path.insert(0, %r); "
                  "import te1_engine as E; "
                  "L = E.Launcher(%r); "
                  "r, pr = L.gk_restore_all(); "
                  "print('restored:', r, 'problems:', pr)"
                  % (str(engine.parent), str(game)))
        p6 = subprocess.run([sys.executable, "-c", script],
                            capture_output=True, text=True, encoding="utf-8")
        check("restore helper ran cleanly", p6.returncode == 0
              and "problems: []" in p6.stdout, p6.stdout + p6.stderr[-300:])
        for n in real_names:
            check("%s byte-identical again" % n,
                  (game / n).read_bytes() == before[game / n])
        check("backups consumed",
              not any((game / "mods" / "original" / "exe").glob("*")))

        print("12. --check-exe says what a file really is")
        p9 = run(engine, game4, "--check-exe", str(victim4))
        check("check-exe exits cleanly", p9.returncode == 0, p9.stderr[-300:])
        check("check-exe reports a valid patched exe",
              "VALID" in p9.stdout and "sha1" in p9.stdout, p9.stdout[-400:])
        check("check-exe lists the officer names",
              "Cell Key" in p9.stdout and "Work Key" in p9.stdout,
              p9.stdout[-400:])
        p10 = run(engine, game4, "--check-exe", str(samples[0]))
        check("a pristine exe reads as 'mod is NOT installed'",
              "NOT installed" in p10.stdout, p10.stdout[-300:])
        front = game4 / "TheEscapists.exe"
        if front.exists():
            p11 = run(engine, game4, "--check-exe", str(front))
            check("the front end is recognised, not called broken",
                  "front end" in p11.stdout and "DAMAGED" not in p11.stdout,
                  p11.stdout[-300:])
        broken = work / "broken.exe"
        broken.write_bytes(victim4.read_bytes()[:len(pristine4) // 3])
        p12 = run(engine, game4, "--check-exe", str(broken))
        check("a truncated file is called DAMAGED",
              "DAMAGED" in p12.stdout, p12.stdout[-400:])
        check("and the fix is spelled out",
              "--revert-exe" in p12.stdout, p12.stdout[-400:])
        # a renamed .txt dump - exactly how a player sends an exe in
        shipped = work / "TheEscapists_eur.exe.txt"
        shipped.write_bytes(victim4.read_bytes())
        p13 = run(engine, game4, "--check-exe", str(shipped))
        check("a .exe.txt copy is checked like the exe",
              "VALID" in p13.stdout, p13.stdout[-300:])
        p14 = run(engine, game4, "--check-exe", str(game4))
        check("a folder checks every exe inside",
              "TheEscapists.exe" in p14.stdout
              and "theescapists_eur.exe" in p14.stdout, p14.stdout[-500:])

        print("13. --verify preflight reads Data\\ the way the game does")
        p15 = run(engine, game4, "--verify")
        check("verify passes on a healthy folder", p15.returncode == 0
              and "All good" in p15.stdout, p15.stdout[-400:])
        check("every exe is listed", "theescapists_eur.exe" in p15.stdout)
        check("Data files are listed", "items_rus.dat" in p15.stdout)
        # a file that grew by hand: decodable, but val.dat disagrees
        it = game4 / "Data" / "items_rus.dat"
        grew = it.read_bytes() + b" " * 8
        it.write_bytes(grew)
        p16 = run(engine, game4, "--verify")
        check("a file that no longer matches val.dat is caught",
              p16.returncode == 1 and "val.dat" in p16.stdout,
              p16.stdout[-400:])
        # and a file that is simply cut in half
        it.write_bytes(grew[:len(grew) // 2] + b"\x00" * 4)
        p17 = run(engine, game4, "--verify")
        check("a truncated Data file is caught",
              p17.returncode == 1, p17.stdout[-400:])
        problems, vlines = eng.Launcher(game4).verify_all()
        check("verify_all() reports the damage in code",
              bool(problems) and any("items_rus.dat" in p for p in problems),
              str(problems))

        print("14. --revert-exe is the way out")
        game5 = make_game(work / "revert", samples)
        st5 = game5 / "mods" / "mods.json"
        st5.parent.mkdir(parents=True, exist_ok=True)
        st5.write_text(json.dumps({"guard_keys": True}), encoding="utf-8")
        before5 = {f: f.read_bytes() for f in game5.glob("theescapists_*.exe")}
        run(engine, game5, "--apply")
        check("the exes were really patched first",
              all((game5 / n).read_bytes() != before5[game5 / n]
                  for n in before5))
        p18 = run(engine, game5, "--revert-exe")
        check("revert exits cleanly", p18.returncode == 0, p18.stderr[-300:])
        check("revert says what it put back", "original exe restored"
              in p18.stdout, p18.stdout[-300:])
        check("every exe is pristine again",
              all((game5 / n).read_bytes() == before5[game5 / n]
                  for n in before5))
        state5 = json.loads(st5.read_text("utf-8"))
        check("the mod is switched off in mods.json",
              state5.get("guard_keys") is False, str(state5))

        print("15. game never appeared -> the exe patch is taken out too")
        game6 = make_game(work / "neverstarted", samples)
        st6 = game6 / "mods" / "mods.json"
        st6.parent.mkdir(parents=True, exist_ok=True)
        st6.write_text(json.dumps({"guard_keys": True}), encoding="utf-8")
        before6 = {f: f.read_bytes() for f in game6.glob("theescapists_*.exe")}
        script2 = (
            "import sys; sys.path.insert(0, %r);\n"
            "import te1_engine as E\n"
            "L = E.Launcher(%r)\n"
            "L.load_state()\n"
            "def fake_launch(self):\n"
            "    E.say('  (pretending the game was started)')\n"
            "    self.last_run = 'never'\n"
            "    return True\n"
            "E.Launcher.launch = fake_launch\n"
            "E.screen_launch(L)\n"
            "print('state:', L.state)\n"
            % (str(engine.parent), str(game6)))
        q = subprocess.run([sys.executable, "-c", script2],
                           stdin=subprocess.DEVNULL, capture_output=True,
                           text=True, encoding="utf-8")
        check("screen_launch ran cleanly", q.returncode == 0,
              (q.stdout + q.stderr)[-400:])
        check("the officer patch was taken out",
              "original exe restored" in q.stdout and "switched off"
              in q.stdout, q.stdout[-600:])
        check("every exe is pristine again",
              all((game6 / n).read_bytes() == before6[game6 / n]
                  for n in before6), "still patched")
        state6 = json.loads(st6.read_text("utf-8"))
        check("mods.json has guard_keys off",
              state6.get("guard_keys") is False, str(state6))

        print("16. the Diagnostics menu is the same checks, without typing "
              "keys")
        game7 = make_game(work / "menu", samples)
        st7 = game7 / "mods" / "mods.json"
        st7.parent.mkdir(parents=True, exist_ok=True)
        st7.write_text(json.dumps({"guard_keys": True}), encoding="utf-8")
        run(engine, game7, "--apply")
        victim7 = game7 / real_names[0]
        keys = ("3\n"          # main menu -> Diagnostics
                "1\n\n"         # check every file the game loads
                "2\n\n"         # state of the executables
                "3\n%s\n\n"     # check one file (drag & drop path)
                "4\ny\n\n"      # put the originals back
                "5\n"           # back to the main menu
                "4\n"           # exit
                % str(victim7))
        q2 = subprocess.run([sys.executable, str(engine), "--game",
                             str(game7)],
                            input=keys, capture_output=True, text=True,
                            encoding="utf-8")
        out7 = q2.stdout
        check("the menu exits cleanly", q2.returncode == 0,
              (out7 + q2.stderr)[-400:])
        check("Diagnostics is on the main menu",
              "DIAGNOSTICS" in out7 and "3. Diagnostics" in out7, out7[-300:])
        check("it runs the preflight check",
              "PREFLIGHT" in out7 and "All good" in out7, out7[-400:])
        check("it prints the exe state", "check: VALID" in out7,
              out7[-400:])
        check("it checks a single file", "verdict: VALID" in out7,
              out7[-400:])
        check("it puts the originals back",
              "original exe restored" in out7 and "all mods switched off"
              in out7, out7[-400:])
        check("the exe is pristine again",
              victim7.read_bytes() == pristine4)
        log7 = game7 / "mods" / "launcher_log.txt"
        check("everything is written to mods\\launcher_log.txt",
              log7.exists() and "DIAGNOSTICS" in log7.read_text("utf-8")
              and "engine" in log7.read_text("utf-8"),
              str(log7))
    finally:
        shutil.rmtree(work, ignore_errors=True)

    print("")
    print("ALL GOOD" if ok else "FAILURES ABOVE")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
